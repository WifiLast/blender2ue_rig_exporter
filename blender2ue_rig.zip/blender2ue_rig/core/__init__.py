"""Core module initialization"""
